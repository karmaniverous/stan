/**
 * Library entry point.
 *
 * REQUIREMENTS
 * - Expose the `context` programmatic API for external consumers. [req-export-api]
 */
export * from './context';
